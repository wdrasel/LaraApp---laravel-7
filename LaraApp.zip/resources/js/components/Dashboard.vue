<template>
    <div class="container">
        <div class="row justify-content-center">
            <default></default>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Dashboard",
        mounted() {
            console.log('Component mounted dashboard.')
        }
    }
</script>

<style scoped>

</style>
